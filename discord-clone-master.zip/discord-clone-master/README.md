# Discord clone
- Made using react js
- Uses react router to navigate the user to differnt pages such as login, register, dashboard,server, etc.
### Demo

https://user-images.githubusercontent.com/90552451/149652350-eea590be-7551-4365-b6c2-3b99165997d5.mp4

